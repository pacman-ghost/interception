#ifndef _UTILS_H_
#define _UTILS_H_

#ifdef __cplusplus
extern "C" {
#endif

void raise_process_priority(void);
void lower_process_priority(void);

#ifdef __cplusplus
}
#endif

#endif
